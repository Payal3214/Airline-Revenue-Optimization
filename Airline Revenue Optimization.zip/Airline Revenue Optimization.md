```python
import sqlite3
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns
import json

import warnings
warnings.filterwarnings('ignore')
```


```python
pip install seaborn
```

    Defaulting to user installation because normal site-packages is not writeableNote: you may need to restart the kernel to use updated packages.
    
    Requirement already satisfied: seaborn in c:\programdata\anaconda3\lib\site-packages (0.11.2)
    Requirement already satisfied: pandas>=0.23 in c:\programdata\anaconda3\lib\site-packages (from seaborn) (1.4.2)
    Requirement already satisfied: scipy>=1.0 in c:\programdata\anaconda3\lib\site-packages (from seaborn) (1.7.3)
    Requirement already satisfied: matplotlib>=2.2 in c:\programdata\anaconda3\lib\site-packages (from seaborn) (3.5.1)
    Requirement already satisfied: numpy>=1.15 in c:\users\user\appdata\roaming\python\python39\site-packages (from seaborn) (1.22.4)
    Requirement already satisfied: kiwisolver>=1.0.1 in c:\programdata\anaconda3\lib\site-packages (from matplotlib>=2.2->seaborn) (1.3.2)
    Requirement already satisfied: pillow>=6.2.0 in c:\programdata\anaconda3\lib\site-packages (from matplotlib>=2.2->seaborn) (9.0.1)
    Requirement already satisfied: fonttools>=4.22.0 in c:\programdata\anaconda3\lib\site-packages (from matplotlib>=2.2->seaborn) (4.25.0)
    Requirement already satisfied: pyparsing>=2.2.1 in c:\programdata\anaconda3\lib\site-packages (from matplotlib>=2.2->seaborn) (3.0.4)
    Requirement already satisfied: python-dateutil>=2.7 in c:\programdata\anaconda3\lib\site-packages (from matplotlib>=2.2->seaborn) (2.8.2)
    Requirement already satisfied: packaging>=20.0 in c:\programdata\anaconda3\lib\site-packages (from matplotlib>=2.2->seaborn) (21.3)
    Requirement already satisfied: cycler>=0.10 in c:\programdata\anaconda3\lib\site-packages (from matplotlib>=2.2->seaborn) (0.11.0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\user\appdata\roaming\python\python39\site-packages (from pandas>=0.23->seaborn) (2023.3.post1)
    Requirement already satisfied: six>=1.5 in c:\programdata\anaconda3\lib\site-packages (from python-dateutil>=2.7->matplotlib>=2.2->seaborn) (1.16.0)
    


```python
conn = sqlite3.connect('airlines_db.sqlite')
cursor = conn.cursor()
```


```python
tables = pd.read_sql("""SELECT *
                        FROM sqlite_master
                        WHERE type='table';""", conn)
tables
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>type</th>
      <th>name</th>
      <th>tbl_name</th>
      <th>rootpage</th>
      <th>sql</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>table</td>
      <td>aircrafts_data</td>
      <td>aircrafts_data</td>
      <td>2</td>
      <td>CREATE TABLE aircrafts_data (\r\n    aircraft_...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>table</td>
      <td>airports_data</td>
      <td>airports_data</td>
      <td>3</td>
      <td>CREATE TABLE airports_data (\r\n    airport_co...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>table</td>
      <td>boarding_passes</td>
      <td>boarding_passes</td>
      <td>4</td>
      <td>CREATE TABLE boarding_passes (\r\n    ticket_n...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>table</td>
      <td>bookings</td>
      <td>bookings</td>
      <td>5</td>
      <td>CREATE TABLE bookings (\r\n    book_ref charac...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>table</td>
      <td>flights</td>
      <td>flights</td>
      <td>6</td>
      <td>CREATE TABLE flights (\r\n    flight_id intege...</td>
    </tr>
    <tr>
      <th>5</th>
      <td>table</td>
      <td>seats</td>
      <td>seats</td>
      <td>7</td>
      <td>CREATE TABLE seats (\r\n    aircraft_code char...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>table</td>
      <td>ticket_flights</td>
      <td>ticket_flights</td>
      <td>8</td>
      <td>CREATE TABLE ticket_flights (\r\n    ticket_no...</td>
    </tr>
    <tr>
      <th>7</th>
      <td>table</td>
      <td>tickets</td>
      <td>tickets</td>
      <td>9</td>
      <td>CREATE TABLE tickets (\r\n    ticket_no charac...</td>
    </tr>
  </tbody>
</table>
</div>




```python
aircrafts_data = pd.read_sql_query("select * from aircrafts_data", conn)
aircrafts_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>aircraft_code</th>
      <th>model</th>
      <th>range</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>773</td>
      <td>{"en": "Boeing 777-300", "ru": "Боинг 777-300"}</td>
      <td>11100</td>
    </tr>
    <tr>
      <th>1</th>
      <td>763</td>
      <td>{"en": "Boeing 767-300", "ru": "Боинг 767-300"}</td>
      <td>7900</td>
    </tr>
    <tr>
      <th>2</th>
      <td>SU9</td>
      <td>{"en": "Sukhoi Superjet-100", "ru": "Сухой Суп...</td>
      <td>3000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>320</td>
      <td>{"en": "Airbus A320-200", "ru": "Аэробус A320-...</td>
      <td>5700</td>
    </tr>
    <tr>
      <th>4</th>
      <td>321</td>
      <td>{"en": "Airbus A321-200", "ru": "Аэробус A321-...</td>
      <td>5600</td>
    </tr>
    <tr>
      <th>5</th>
      <td>319</td>
      <td>{"en": "Airbus A319-100", "ru": "Аэробус A319-...</td>
      <td>6700</td>
    </tr>
    <tr>
      <th>6</th>
      <td>733</td>
      <td>{"en": "Boeing 737-300", "ru": "Боинг 737-300"}</td>
      <td>4200</td>
    </tr>
    <tr>
      <th>7</th>
      <td>CN1</td>
      <td>{"en": "Cessna 208 Caravan", "ru": "Сессна 208...</td>
      <td>1200</td>
    </tr>
    <tr>
      <th>8</th>
      <td>CR2</td>
      <td>{"en": "Bombardier CRJ-200", "ru": "Бомбардье ...</td>
      <td>2700</td>
    </tr>
  </tbody>
</table>
</div>




```python
airports_data = pd.read_sql_query("""SELECT * FROM airports_data""", conn)

airports_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>airport_code</th>
      <th>airport_name</th>
      <th>city</th>
      <th>coordinates</th>
      <th>timezone</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>YKS</td>
      <td>{"en": "Yakutsk Airport", "ru": "Якутск"}</td>
      <td>{"en": "Yakutsk", "ru": "Якутск"}</td>
      <td>(129.77099609375,62.0932998657226562)</td>
      <td>Asia/Yakutsk</td>
    </tr>
    <tr>
      <th>1</th>
      <td>MJZ</td>
      <td>{"en": "Mirny Airport", "ru": "Мирный"}</td>
      <td>{"en": "Mirnyj", "ru": "Мирный"}</td>
      <td>(114.03900146484375,62.534698486328125)</td>
      <td>Asia/Yakutsk</td>
    </tr>
    <tr>
      <th>2</th>
      <td>KHV</td>
      <td>{"en": "Khabarovsk-Novy Airport", "ru": "Хабар...</td>
      <td>{"en": "Khabarovsk", "ru": "Хабаровск"}</td>
      <td>(135.18800354004,48.5279998779300001)</td>
      <td>Asia/Vladivostok</td>
    </tr>
    <tr>
      <th>3</th>
      <td>PKC</td>
      <td>{"en": "Yelizovo Airport", "ru": "Елизово"}</td>
      <td>{"en": "Petropavlovsk", "ru": "Петропавловск-К...</td>
      <td>(158.453994750976562,53.1679000854492188)</td>
      <td>Asia/Kamchatka</td>
    </tr>
    <tr>
      <th>4</th>
      <td>UUS</td>
      <td>{"en": "Yuzhno-Sakhalinsk Airport", "ru": "Хом...</td>
      <td>{"en": "Yuzhno-Sakhalinsk", "ru": "Южно-Сахали...</td>
      <td>(142.718002319335938,46.8886985778808594)</td>
      <td>Asia/Sakhalin</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>99</th>
      <td>MMK</td>
      <td>{"en": "Murmansk Airport", "ru": "Мурманск"}</td>
      <td>{"en": "Murmansk", "ru": "Мурманск"}</td>
      <td>(32.7508010864257812,68.7817001342773438)</td>
      <td>Europe/Moscow</td>
    </tr>
    <tr>
      <th>100</th>
      <td>ABA</td>
      <td>{"en": "Abakan Airport", "ru": "Абакан"}</td>
      <td>{"en": "Abakan", "ru": "Абакан"}</td>
      <td>(91.3850021362304688,53.7400016784667969)</td>
      <td>Asia/Krasnoyarsk</td>
    </tr>
    <tr>
      <th>101</th>
      <td>BAX</td>
      <td>{"en": "Barnaul Airport", "ru": "Барнаул"}</td>
      <td>{"en": "Barnaul", "ru": "Барнаул"}</td>
      <td>(83.5384979248046875,53.363800048828125)</td>
      <td>Asia/Krasnoyarsk</td>
    </tr>
    <tr>
      <th>102</th>
      <td>AAQ</td>
      <td>{"en": "Anapa Vityazevo Airport", "ru": "Витяз...</td>
      <td>{"en": "Anapa", "ru": "Анапа"}</td>
      <td>(37.3473014831539984,45.002101898192997)</td>
      <td>Europe/Moscow</td>
    </tr>
    <tr>
      <th>103</th>
      <td>CNN</td>
      <td>{"en": "Chulman Airport", "ru": "Чульман"}</td>
      <td>{"en": "Neryungri", "ru": "Нерюнгри"}</td>
      <td>(124.914001464839998,56.9138984680179973)</td>
      <td>Asia/Yakutsk</td>
    </tr>
  </tbody>
</table>
<p>104 rows × 5 columns</p>
</div>




```python
airports_data = pd.read_sql_query("""SELECT * FROM airports_data""", conn)

airports_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>airport_code</th>
      <th>airport_name</th>
      <th>city</th>
      <th>coordinates</th>
      <th>timezone</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>YKS</td>
      <td>{"en": "Yakutsk Airport", "ru": "Якутск"}</td>
      <td>{"en": "Yakutsk", "ru": "Якутск"}</td>
      <td>(129.77099609375,62.0932998657226562)</td>
      <td>Asia/Yakutsk</td>
    </tr>
    <tr>
      <th>1</th>
      <td>MJZ</td>
      <td>{"en": "Mirny Airport", "ru": "Мирный"}</td>
      <td>{"en": "Mirnyj", "ru": "Мирный"}</td>
      <td>(114.03900146484375,62.534698486328125)</td>
      <td>Asia/Yakutsk</td>
    </tr>
    <tr>
      <th>2</th>
      <td>KHV</td>
      <td>{"en": "Khabarovsk-Novy Airport", "ru": "Хабар...</td>
      <td>{"en": "Khabarovsk", "ru": "Хабаровск"}</td>
      <td>(135.18800354004,48.5279998779300001)</td>
      <td>Asia/Vladivostok</td>
    </tr>
    <tr>
      <th>3</th>
      <td>PKC</td>
      <td>{"en": "Yelizovo Airport", "ru": "Елизово"}</td>
      <td>{"en": "Petropavlovsk", "ru": "Петропавловск-К...</td>
      <td>(158.453994750976562,53.1679000854492188)</td>
      <td>Asia/Kamchatka</td>
    </tr>
    <tr>
      <th>4</th>
      <td>UUS</td>
      <td>{"en": "Yuzhno-Sakhalinsk Airport", "ru": "Хом...</td>
      <td>{"en": "Yuzhno-Sakhalinsk", "ru": "Южно-Сахали...</td>
      <td>(142.718002319335938,46.8886985778808594)</td>
      <td>Asia/Sakhalin</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>99</th>
      <td>MMK</td>
      <td>{"en": "Murmansk Airport", "ru": "Мурманск"}</td>
      <td>{"en": "Murmansk", "ru": "Мурманск"}</td>
      <td>(32.7508010864257812,68.7817001342773438)</td>
      <td>Europe/Moscow</td>
    </tr>
    <tr>
      <th>100</th>
      <td>ABA</td>
      <td>{"en": "Abakan Airport", "ru": "Абакан"}</td>
      <td>{"en": "Abakan", "ru": "Абакан"}</td>
      <td>(91.3850021362304688,53.7400016784667969)</td>
      <td>Asia/Krasnoyarsk</td>
    </tr>
    <tr>
      <th>101</th>
      <td>BAX</td>
      <td>{"en": "Barnaul Airport", "ru": "Барнаул"}</td>
      <td>{"en": "Barnaul", "ru": "Барнаул"}</td>
      <td>(83.5384979248046875,53.363800048828125)</td>
      <td>Asia/Krasnoyarsk</td>
    </tr>
    <tr>
      <th>102</th>
      <td>AAQ</td>
      <td>{"en": "Anapa Vityazevo Airport", "ru": "Витяз...</td>
      <td>{"en": "Anapa", "ru": "Анапа"}</td>
      <td>(37.3473014831539984,45.002101898192997)</td>
      <td>Europe/Moscow</td>
    </tr>
    <tr>
      <th>103</th>
      <td>CNN</td>
      <td>{"en": "Chulman Airport", "ru": "Чульман"}</td>
      <td>{"en": "Neryungri", "ru": "Нерюнгри"}</td>
      <td>(124.914001464839998,56.9138984680179973)</td>
      <td>Asia/Yakutsk</td>
    </tr>
  </tbody>
</table>
<p>104 rows × 5 columns</p>
</div>




```python
boarding_passes =  pd.read_sql_query("""SELECT * FROM boarding_passes""",conn)

boarding_passes
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ticket_no</th>
      <th>flight_id</th>
      <th>boarding_no</th>
      <th>seat_no</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0005435212351</td>
      <td>30625</td>
      <td>1</td>
      <td>2D</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0005435212386</td>
      <td>30625</td>
      <td>2</td>
      <td>3G</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0005435212381</td>
      <td>30625</td>
      <td>3</td>
      <td>4H</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0005432211370</td>
      <td>30625</td>
      <td>4</td>
      <td>5D</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0005435212357</td>
      <td>30625</td>
      <td>5</td>
      <td>11A</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>579681</th>
      <td>0005434302871</td>
      <td>19945</td>
      <td>85</td>
      <td>20F</td>
    </tr>
    <tr>
      <th>579682</th>
      <td>0005432892791</td>
      <td>19945</td>
      <td>86</td>
      <td>21C</td>
    </tr>
    <tr>
      <th>579683</th>
      <td>0005434302869</td>
      <td>19945</td>
      <td>87</td>
      <td>20E</td>
    </tr>
    <tr>
      <th>579684</th>
      <td>0005432802476</td>
      <td>19945</td>
      <td>88</td>
      <td>21F</td>
    </tr>
    <tr>
      <th>579685</th>
      <td>0005432802482</td>
      <td>19945</td>
      <td>89</td>
      <td>21E</td>
    </tr>
  </tbody>
</table>
<p>579686 rows × 4 columns</p>
</div>




```python
bookings  =  pd.read_sql_query("""SELECT * FROM bookings""", conn)

bookings
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>book_ref</th>
      <th>book_date</th>
      <th>total_amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>00000F</td>
      <td>2017-07-05 03:12:00+03</td>
      <td>265700</td>
    </tr>
    <tr>
      <th>1</th>
      <td>000012</td>
      <td>2017-07-14 09:02:00+03</td>
      <td>37900</td>
    </tr>
    <tr>
      <th>2</th>
      <td>000068</td>
      <td>2017-08-15 14:27:00+03</td>
      <td>18100</td>
    </tr>
    <tr>
      <th>3</th>
      <td>000181</td>
      <td>2017-08-10 13:28:00+03</td>
      <td>131800</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0002D8</td>
      <td>2017-08-07 21:40:00+03</td>
      <td>23600</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>262783</th>
      <td>FFFEF3</td>
      <td>2017-07-17 07:23:00+03</td>
      <td>56000</td>
    </tr>
    <tr>
      <th>262784</th>
      <td>FFFF2C</td>
      <td>2017-08-08 05:55:00+03</td>
      <td>10800</td>
    </tr>
    <tr>
      <th>262785</th>
      <td>FFFF43</td>
      <td>2017-07-20 20:42:00+03</td>
      <td>78500</td>
    </tr>
    <tr>
      <th>262786</th>
      <td>FFFFA8</td>
      <td>2017-08-08 04:45:00+03</td>
      <td>28800</td>
    </tr>
    <tr>
      <th>262787</th>
      <td>FFFFF7</td>
      <td>2017-07-01 22:12:00+03</td>
      <td>73600</td>
    </tr>
  </tbody>
</table>
<p>262788 rows × 3 columns</p>
</div>




```python
flights =  pd.read_sql_query("""SELECT * FROM flights""",conn)
flights
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>flight_id</th>
      <th>flight_no</th>
      <th>scheduled_departure</th>
      <th>scheduled_arrival</th>
      <th>departure_airport</th>
      <th>arrival_airport</th>
      <th>status</th>
      <th>aircraft_code</th>
      <th>actual_departure</th>
      <th>actual_arrival</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1185</td>
      <td>PG0134</td>
      <td>2017-09-10 09:50:00+03</td>
      <td>2017-09-10 14:55:00+03</td>
      <td>DME</td>
      <td>BTK</td>
      <td>Scheduled</td>
      <td>319</td>
      <td>\N</td>
      <td>\N</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3979</td>
      <td>PG0052</td>
      <td>2017-08-25 14:50:00+03</td>
      <td>2017-08-25 17:35:00+03</td>
      <td>VKO</td>
      <td>HMA</td>
      <td>Scheduled</td>
      <td>CR2</td>
      <td>\N</td>
      <td>\N</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4739</td>
      <td>PG0561</td>
      <td>2017-09-05 12:30:00+03</td>
      <td>2017-09-05 14:15:00+03</td>
      <td>VKO</td>
      <td>AER</td>
      <td>Scheduled</td>
      <td>763</td>
      <td>\N</td>
      <td>\N</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5502</td>
      <td>PG0529</td>
      <td>2017-09-12 09:50:00+03</td>
      <td>2017-09-12 11:20:00+03</td>
      <td>SVO</td>
      <td>UFA</td>
      <td>Scheduled</td>
      <td>763</td>
      <td>\N</td>
      <td>\N</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6938</td>
      <td>PG0461</td>
      <td>2017-09-04 12:25:00+03</td>
      <td>2017-09-04 13:20:00+03</td>
      <td>SVO</td>
      <td>ULV</td>
      <td>Scheduled</td>
      <td>SU9</td>
      <td>\N</td>
      <td>\N</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>33116</th>
      <td>33117</td>
      <td>PG0063</td>
      <td>2017-08-02 19:25:00+03</td>
      <td>2017-08-02 20:10:00+03</td>
      <td>SKX</td>
      <td>SVO</td>
      <td>Arrived</td>
      <td>CR2</td>
      <td>2017-08-02 19:25:00+03</td>
      <td>2017-08-02 20:10:00+03</td>
    </tr>
    <tr>
      <th>33117</th>
      <td>33118</td>
      <td>PG0063</td>
      <td>2017-07-28 19:25:00+03</td>
      <td>2017-07-28 20:10:00+03</td>
      <td>SKX</td>
      <td>SVO</td>
      <td>Arrived</td>
      <td>CR2</td>
      <td>2017-07-28 19:30:00+03</td>
      <td>2017-07-28 20:15:00+03</td>
    </tr>
    <tr>
      <th>33118</th>
      <td>33119</td>
      <td>PG0063</td>
      <td>2017-09-08 19:25:00+03</td>
      <td>2017-09-08 20:10:00+03</td>
      <td>SKX</td>
      <td>SVO</td>
      <td>Scheduled</td>
      <td>CR2</td>
      <td>\N</td>
      <td>\N</td>
    </tr>
    <tr>
      <th>33119</th>
      <td>33120</td>
      <td>PG0063</td>
      <td>2017-08-01 19:25:00+03</td>
      <td>2017-08-01 20:10:00+03</td>
      <td>SKX</td>
      <td>SVO</td>
      <td>Arrived</td>
      <td>CR2</td>
      <td>2017-08-01 19:26:00+03</td>
      <td>2017-08-01 20:12:00+03</td>
    </tr>
    <tr>
      <th>33120</th>
      <td>33121</td>
      <td>PG0063</td>
      <td>2017-08-26 19:25:00+03</td>
      <td>2017-08-26 20:10:00+03</td>
      <td>SKX</td>
      <td>SVO</td>
      <td>Scheduled</td>
      <td>CR2</td>
      <td>\N</td>
      <td>\N</td>
    </tr>
  </tbody>
</table>
<p>33121 rows × 10 columns</p>
</div>




```python
seats  =  pd.read_sql_query("""SELECT * FROM seats""",conn)

seats
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>aircraft_code</th>
      <th>seat_no</th>
      <th>fare_conditions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>319</td>
      <td>2A</td>
      <td>Business</td>
    </tr>
    <tr>
      <th>1</th>
      <td>319</td>
      <td>2C</td>
      <td>Business</td>
    </tr>
    <tr>
      <th>2</th>
      <td>319</td>
      <td>2D</td>
      <td>Business</td>
    </tr>
    <tr>
      <th>3</th>
      <td>319</td>
      <td>2F</td>
      <td>Business</td>
    </tr>
    <tr>
      <th>4</th>
      <td>319</td>
      <td>3A</td>
      <td>Business</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1334</th>
      <td>773</td>
      <td>48H</td>
      <td>Economy</td>
    </tr>
    <tr>
      <th>1335</th>
      <td>773</td>
      <td>48K</td>
      <td>Economy</td>
    </tr>
    <tr>
      <th>1336</th>
      <td>773</td>
      <td>49A</td>
      <td>Economy</td>
    </tr>
    <tr>
      <th>1337</th>
      <td>773</td>
      <td>49C</td>
      <td>Economy</td>
    </tr>
    <tr>
      <th>1338</th>
      <td>773</td>
      <td>49D</td>
      <td>Economy</td>
    </tr>
  </tbody>
</table>
<p>1339 rows × 3 columns</p>
</div>




```python
ticket_flights  =  pd.read_sql_query("""SELECT * FROM ticket_flights""",conn)

ticket_flights.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ticket_no</th>
      <th>flight_id</th>
      <th>fare_conditions</th>
      <th>amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0005432159776</td>
      <td>30625</td>
      <td>Business</td>
      <td>42100</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0005435212351</td>
      <td>30625</td>
      <td>Business</td>
      <td>42100</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0005435212386</td>
      <td>30625</td>
      <td>Business</td>
      <td>42100</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0005435212381</td>
      <td>30625</td>
      <td>Business</td>
      <td>42100</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0005432211370</td>
      <td>30625</td>
      <td>Business</td>
      <td>42100</td>
    </tr>
  </tbody>
</table>
</div>




```python
tickets  =  pd.read_sql_query("""SELECT * FROM tickets""",conn)

tickets.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ticket_no</th>
      <th>book_ref</th>
      <th>passenger_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0005432000987</td>
      <td>06B046</td>
      <td>8149 604011</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0005432000988</td>
      <td>06B046</td>
      <td>8499 420203</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0005432000989</td>
      <td>E170C3</td>
      <td>1011 752484</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0005432000990</td>
      <td>E170C3</td>
      <td>4849 400049</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0005432000991</td>
      <td>F313DD</td>
      <td>6615 976589</td>
    </tr>
  </tbody>
</table>
</div>




```python
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import json

# Assuming 'aircrafts_data' is your DataFrame containing the aircraft data

# Print the initial 'model' column to see what the data looks like
print("Initial 'model' column:")
print(aircrafts_data['model'].head())

# Define a function to safely load JSON or return None for non-JSON values
def safe_load_json(x):
    try:
        return json.loads(x)['en']
    except (json.JSONDecodeError, TypeError, KeyError):
        return None

# Test the function with sample data
print("Testing safe_load_json function:")
print(safe_load_json('{"en": "Boeing 737"}'))  # Expected output: Boeing 737
print(safe_load_json('{"wrong_key": "value"}'))  # Expected output: None
print(safe_load_json('Invalid JSON'))  # Expected output: None

# Apply the function to the 'model' column
aircrafts_data['model'] = aircrafts_data['model'].apply(safe_load_json)

# Print the 'model' column after applying the function
print("Modified 'model' column:")
print(aircrafts_data['model'].head())

# Drop rows where 'model' is None (indicating it was not valid JSON or missing 'en' field)
aircrafts_data = aircrafts_data.dropna(subset=['model'])

# Ensure 'range' is numeric
aircrafts_data['range'] = pd.to_numeric(aircrafts_data['range'], errors='coerce')

# Check the data after conversion and dropping NaN values
print("Data after cleaning:")
print(aircrafts_data.head())
print(aircrafts_data.info())

# Plot the data
sns.set_style('dark')
fig, axes = plt.subplots(figsize=(12, 8))
ax = sns.barplot(x='model', y='range', data=aircrafts_data, palette='Paired')
for container in ax.containers:
    ax.bar_label(container)
plt.title('Airplane Models with Their Ranges')
plt.xticks(rotation=45)
plt.show()


     
    








```

    Initial 'model' column:
    0      {"en": "Boeing 777-300", "ru": "Боинг 777-300"}
    1      {"en": "Boeing 767-300", "ru": "Боинг 767-300"}
    2    {"en": "Sukhoi Superjet-100", "ru": "Сухой Суп...
    3    {"en": "Airbus A320-200", "ru": "Аэробус A320-...
    4    {"en": "Airbus A321-200", "ru": "Аэробус A321-...
    Name: model, dtype: object
    Testing safe_load_json function:
    Boeing 737
    None
    None
    Modified 'model' column:
    0         Boeing 777-300
    1         Boeing 767-300
    2    Sukhoi Superjet-100
    3        Airbus A320-200
    4        Airbus A321-200
    Name: model, dtype: object
    Data after cleaning:
      aircraft_code                model  range
    0           773       Boeing 777-300  11100
    1           763       Boeing 767-300   7900
    2           SU9  Sukhoi Superjet-100   3000
    3           320      Airbus A320-200   5700
    4           321      Airbus A321-200   5600
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 9 entries, 0 to 8
    Data columns (total 3 columns):
     #   Column         Non-Null Count  Dtype 
    ---  ------         --------------  ----- 
     0   aircraft_code  9 non-null      object
     1   model          9 non-null      object
     2   range          9 non-null      int64 
    dtypes: int64(1), object(2)
    memory usage: 344.0+ bytes
    None
    


    
![png](output_13_1.png)
    



```python
df1  =  pd.read_sql_query("""SELECT s.aircraft_code, JSON_EXTRACT(model, '$.en') AS model, COUNT(*) AS num_seats 
                             FROM seats AS s
                             JOIN aircrafts_data AS a
                             ON s.aircraft_code = a.aircraft_code
                             GROUP BY s.aircraft_code
                             HAVING num_seats > 100
                             ORDER BY num_seats DESC""", conn)

df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>aircraft_code</th>
      <th>model</th>
      <th>num_seats</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>773</td>
      <td>Boeing 777-300</td>
      <td>402</td>
    </tr>
    <tr>
      <th>1</th>
      <td>763</td>
      <td>Boeing 767-300</td>
      <td>222</td>
    </tr>
    <tr>
      <th>2</th>
      <td>321</td>
      <td>Airbus A321-200</td>
      <td>170</td>
    </tr>
    <tr>
      <th>3</th>
      <td>320</td>
      <td>Airbus A320-200</td>
      <td>140</td>
    </tr>
    <tr>
      <th>4</th>
      <td>733</td>
      <td>Boeing 737-300</td>
      <td>130</td>
    </tr>
    <tr>
      <th>5</th>
      <td>319</td>
      <td>Airbus A319-100</td>
      <td>116</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.set_style('dark')
plt.figure(figsize = (8,4))
ax  =  sns.barplot(x = 'model', y = 'num_seats', data = df1, palette = 'magma')

for container in ax.containers:
    ax.bar_label(container)

plt.title('AirCrafts Having >100 Number of Seats')
plt.xticks(rotation = 45)
plt.show()
```


    
![png](output_15_0.png)
    



```python
tickets = pd.read_sql_query("""select ticket_no, SUBSTR(book_date,1,10) AS date, total_amount from tickets inner join bookings
                    on tickets.book_ref = bookings.book_ref
                    group by date
                    order by date""", conn)

tickets.head(30)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ticket_no</th>
      <th>date</th>
      <th>total_amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0005432628587</td>
      <td>2017-06-21</td>
      <td>52000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0005432984533</td>
      <td>2017-06-22</td>
      <td>123000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0005432150056</td>
      <td>2017-06-23</td>
      <td>64700</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0005432056234</td>
      <td>2017-06-24</td>
      <td>13000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0005432034471</td>
      <td>2017-06-25</td>
      <td>6000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0005432045579</td>
      <td>2017-06-26</td>
      <td>14900</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0005432002041</td>
      <td>2017-06-27</td>
      <td>17600</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0005432003645</td>
      <td>2017-06-28</td>
      <td>99800</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0005432000989</td>
      <td>2017-06-29</td>
      <td>24700</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0005432000999</td>
      <td>2017-06-30</td>
      <td>6200</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0005432002042</td>
      <td>2017-07-01</td>
      <td>18600</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0005432002051</td>
      <td>2017-07-02</td>
      <td>17600</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0005432000991</td>
      <td>2017-07-03</td>
      <td>30900</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0005432000997</td>
      <td>2017-07-04</td>
      <td>6200</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0005432000987</td>
      <td>2017-07-05</td>
      <td>12400</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0005432000996</td>
      <td>2017-07-06</td>
      <td>6200</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0005432000994</td>
      <td>2017-07-07</td>
      <td>13000</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0005432002050</td>
      <td>2017-07-08</td>
      <td>18200</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0005432001008</td>
      <td>2017-07-09</td>
      <td>6800</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0005432002069</td>
      <td>2017-07-10</td>
      <td>48500</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0005432001010</td>
      <td>2017-07-11</td>
      <td>6200</td>
    </tr>
    <tr>
      <th>21</th>
      <td>0005432001005</td>
      <td>2017-07-12</td>
      <td>6200</td>
    </tr>
    <tr>
      <th>22</th>
      <td>0005432001006</td>
      <td>2017-07-13</td>
      <td>12400</td>
    </tr>
    <tr>
      <th>23</th>
      <td>0005432002066</td>
      <td>2017-07-14</td>
      <td>17600</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0005432001019</td>
      <td>2017-07-15</td>
      <td>18500</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0005432001011</td>
      <td>2017-07-16</td>
      <td>6200</td>
    </tr>
    <tr>
      <th>26</th>
      <td>0005432001014</td>
      <td>2017-07-17</td>
      <td>13000</td>
    </tr>
    <tr>
      <th>27</th>
      <td>0005432001016</td>
      <td>2017-07-18</td>
      <td>24700</td>
    </tr>
    <tr>
      <th>28</th>
      <td>0005432001012</td>
      <td>2017-07-19</td>
      <td>6200</td>
    </tr>
    <tr>
      <th>29</th>
      <td>0005432001036</td>
      <td>2017-07-20</td>
      <td>6200</td>
    </tr>
  </tbody>
</table>
</div>




```python
tickets1 = pd.read_sql_query("""select SUBSTR(book_date,1,10) AS date, COUNT(ticket_no) AS tickets, total_amount AS ticket_amount, sum(total_amount) AS amount_sum from tickets inner join bookings
                    on tickets.book_ref = bookings.book_ref
                    group by date
                    order by date""", conn)
# tickets1 = tickets1.set_index('date', drop=True)

tickets1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
      <th>tickets</th>
      <th>ticket_amount</th>
      <th>amount_sum</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2017-06-21</td>
      <td>6</td>
      <td>52000</td>
      <td>916100</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2017-06-22</td>
      <td>12</td>
      <td>123000</td>
      <td>1536300</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2017-06-23</td>
      <td>28</td>
      <td>64700</td>
      <td>3114800</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2017-06-24</td>
      <td>106</td>
      <td>13000</td>
      <td>10279900</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2017-06-25</td>
      <td>266</td>
      <td>6000</td>
      <td>24652200</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2017-06-26</td>
      <td>499</td>
      <td>14900</td>
      <td>48710400</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2017-06-27</td>
      <td>1028</td>
      <td>17600</td>
      <td>88733500</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2017-06-28</td>
      <td>1678</td>
      <td>99800</td>
      <td>147624200</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2017-06-29</td>
      <td>2765</td>
      <td>24700</td>
      <td>248677900</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2017-06-30</td>
      <td>3772</td>
      <td>6200</td>
      <td>337783200</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2017-07-01</td>
      <td>4936</td>
      <td>18600</td>
      <td>467702400</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2017-07-02</td>
      <td>5780</td>
      <td>17600</td>
      <td>543578700</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2017-07-03</td>
      <td>6686</td>
      <td>30900</td>
      <td>638962700</td>
    </tr>
    <tr>
      <th>13</th>
      <td>2017-07-04</td>
      <td>7112</td>
      <td>6200</td>
      <td>669644600</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2017-07-05</td>
      <td>7484</td>
      <td>12400</td>
      <td>706500000</td>
    </tr>
    <tr>
      <th>15</th>
      <td>2017-07-06</td>
      <td>7656</td>
      <td>6200</td>
      <td>715167600</td>
    </tr>
    <tr>
      <th>16</th>
      <td>2017-07-07</td>
      <td>7722</td>
      <td>13000</td>
      <td>731683400</td>
    </tr>
    <tr>
      <th>17</th>
      <td>2017-07-08</td>
      <td>7586</td>
      <td>18200</td>
      <td>708620300</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2017-07-09</td>
      <td>7860</td>
      <td>6800</td>
      <td>721829900</td>
    </tr>
    <tr>
      <th>19</th>
      <td>2017-07-10</td>
      <td>7749</td>
      <td>48500</td>
      <td>725347200</td>
    </tr>
    <tr>
      <th>20</th>
      <td>2017-07-11</td>
      <td>7852</td>
      <td>6200</td>
      <td>709394800</td>
    </tr>
    <tr>
      <th>21</th>
      <td>2017-07-12</td>
      <td>7691</td>
      <td>6200</td>
      <td>706910000</td>
    </tr>
    <tr>
      <th>22</th>
      <td>2017-07-13</td>
      <td>7641</td>
      <td>12400</td>
      <td>713833500</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2017-07-14</td>
      <td>7932</td>
      <td>17600</td>
      <td>757260400</td>
    </tr>
    <tr>
      <th>24</th>
      <td>2017-07-15</td>
      <td>7668</td>
      <td>18500</td>
      <td>725966500</td>
    </tr>
    <tr>
      <th>25</th>
      <td>2017-07-16</td>
      <td>7896</td>
      <td>6200</td>
      <td>733996100</td>
    </tr>
    <tr>
      <th>26</th>
      <td>2017-07-17</td>
      <td>7546</td>
      <td>13000</td>
      <td>708451100</td>
    </tr>
    <tr>
      <th>27</th>
      <td>2017-07-18</td>
      <td>7745</td>
      <td>24700</td>
      <td>722665100</td>
    </tr>
    <tr>
      <th>28</th>
      <td>2017-07-19</td>
      <td>7821</td>
      <td>6200</td>
      <td>765583400</td>
    </tr>
    <tr>
      <th>29</th>
      <td>2017-07-20</td>
      <td>7637</td>
      <td>6200</td>
      <td>731881400</td>
    </tr>
    <tr>
      <th>30</th>
      <td>2017-07-21</td>
      <td>7771</td>
      <td>18200</td>
      <td>716349900</td>
    </tr>
    <tr>
      <th>31</th>
      <td>2017-07-22</td>
      <td>7698</td>
      <td>12400</td>
      <td>705445900</td>
    </tr>
    <tr>
      <th>32</th>
      <td>2017-07-23</td>
      <td>7627</td>
      <td>18500</td>
      <td>717578600</td>
    </tr>
    <tr>
      <th>33</th>
      <td>2017-07-24</td>
      <td>7667</td>
      <td>18600</td>
      <td>709982200</td>
    </tr>
    <tr>
      <th>34</th>
      <td>2017-07-25</td>
      <td>7826</td>
      <td>12400</td>
      <td>757098900</td>
    </tr>
    <tr>
      <th>35</th>
      <td>2017-07-26</td>
      <td>7730</td>
      <td>12400</td>
      <td>706142400</td>
    </tr>
    <tr>
      <th>36</th>
      <td>2017-07-27</td>
      <td>7636</td>
      <td>12400</td>
      <td>713584000</td>
    </tr>
    <tr>
      <th>37</th>
      <td>2017-07-28</td>
      <td>7827</td>
      <td>13000</td>
      <td>741530900</td>
    </tr>
    <tr>
      <th>38</th>
      <td>2017-07-29</td>
      <td>7588</td>
      <td>12400</td>
      <td>704732300</td>
    </tr>
    <tr>
      <th>39</th>
      <td>2017-07-30</td>
      <td>7732</td>
      <td>6200</td>
      <td>719543000</td>
    </tr>
    <tr>
      <th>40</th>
      <td>2017-07-31</td>
      <td>7653</td>
      <td>6200</td>
      <td>725615700</td>
    </tr>
    <tr>
      <th>41</th>
      <td>2017-08-01</td>
      <td>7740</td>
      <td>33300</td>
      <td>744266100</td>
    </tr>
    <tr>
      <th>42</th>
      <td>2017-08-02</td>
      <td>7669</td>
      <td>12400</td>
      <td>736683600</td>
    </tr>
    <tr>
      <th>43</th>
      <td>2017-08-03</td>
      <td>7756</td>
      <td>18500</td>
      <td>705766100</td>
    </tr>
    <tr>
      <th>44</th>
      <td>2017-08-04</td>
      <td>7908</td>
      <td>6200</td>
      <td>751993000</td>
    </tr>
    <tr>
      <th>45</th>
      <td>2017-08-05</td>
      <td>8064</td>
      <td>13000</td>
      <td>749763200</td>
    </tr>
    <tr>
      <th>46</th>
      <td>2017-08-06</td>
      <td>8016</td>
      <td>35200</td>
      <td>756903500</td>
    </tr>
    <tr>
      <th>47</th>
      <td>2017-08-07</td>
      <td>7910</td>
      <td>12400</td>
      <td>745631800</td>
    </tr>
    <tr>
      <th>48</th>
      <td>2017-08-08</td>
      <td>8153</td>
      <td>12400</td>
      <td>777964800</td>
    </tr>
    <tr>
      <th>49</th>
      <td>2017-08-09</td>
      <td>8258</td>
      <td>6200</td>
      <td>795323800</td>
    </tr>
    <tr>
      <th>50</th>
      <td>2017-08-10</td>
      <td>8493</td>
      <td>12400</td>
      <td>804007000</td>
    </tr>
    <tr>
      <th>51</th>
      <td>2017-08-11</td>
      <td>8737</td>
      <td>6200</td>
      <td>828839200</td>
    </tr>
    <tr>
      <th>52</th>
      <td>2017-08-12</td>
      <td>8870</td>
      <td>17600</td>
      <td>816555000</td>
    </tr>
    <tr>
      <th>53</th>
      <td>2017-08-13</td>
      <td>9151</td>
      <td>6200</td>
      <td>838152000</td>
    </tr>
    <tr>
      <th>54</th>
      <td>2017-08-14</td>
      <td>9574</td>
      <td>30900</td>
      <td>873462400</td>
    </tr>
    <tr>
      <th>55</th>
      <td>2017-08-15</td>
      <td>7519</td>
      <td>17600</td>
      <td>660696300</td>
    </tr>
  </tbody>
</table>
</div>




```python
tickets1['date'] = pd.to_datetime(tickets1['date'])
```


```python
plt.figure(figsize=(18, 6))

plt.plot(tickets1.date, tickets1.tickets, label='Tickets', color='cyan', scalex=True, marker='*', markeredgecolor = 'black')

plt.title('Number of Tickets Booked on Each Date', fontsize=30)
plt.xlabel('Date', fontsize=20)
plt.ylabel('Number of Tickets', fontsize=20)
plt.grid('dark')
plt.tight_layout()  # Ensures all elements fit within the figure area
plt.show()
```


    
![png](output_19_0.png)
    



```python
plt.figure(figsize=(18, 6))

# Plot the 'amount_sum' line
plt.plot(tickets1.date, tickets1.amount_sum, label='Amount Sum', color='mediumvioletred', marker='o', markeredgecolor='black')

plt.title('Sum of Amount Earned on Each Date', fontsize=30)
plt.xlabel('Date', fontsize=20)
plt.ylabel('Value', fontsize=20)
plt.grid('dark')
plt.tight_layout()

plt.show()
```


    
![png](output_20_0.png)
    



```python
df2 = pd.read_sql_query("""SELECT a.aircraft_code, JSON_EXTRACT(model, '$.en') AS model,
                            tf.fare_conditions AS class, avg(tf.amount) AS avg_amount
                            FROM aircrafts_data AS a
                            JOIN flights AS f
                            ON a.aircraft_code = f.aircraft_code
                            JOIN ticket_flights AS tf
                            ON f.flight_id = tf.flight_id
                            GROUP BY model, class
                            ORDER BY avg_amount DESC""", conn)

df2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>aircraft_code</th>
      <th>model</th>
      <th>class</th>
      <th>avg_amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>319</td>
      <td>Airbus A319-100</td>
      <td>Business</td>
      <td>113550.557703</td>
    </tr>
    <tr>
      <th>1</th>
      <td>763</td>
      <td>Boeing 767-300</td>
      <td>Business</td>
      <td>82839.842866</td>
    </tr>
    <tr>
      <th>2</th>
      <td>773</td>
      <td>Boeing 777-300</td>
      <td>Business</td>
      <td>57779.909435</td>
    </tr>
    <tr>
      <th>3</th>
      <td>733</td>
      <td>Boeing 737-300</td>
      <td>Business</td>
      <td>41865.626175</td>
    </tr>
    <tr>
      <th>4</th>
      <td>319</td>
      <td>Airbus A319-100</td>
      <td>Economy</td>
      <td>38311.402347</td>
    </tr>
    <tr>
      <th>5</th>
      <td>321</td>
      <td>Airbus A321-200</td>
      <td>Business</td>
      <td>34435.662664</td>
    </tr>
    <tr>
      <th>6</th>
      <td>SU9</td>
      <td>Sukhoi Superjet-100</td>
      <td>Business</td>
      <td>33487.849829</td>
    </tr>
    <tr>
      <th>7</th>
      <td>773</td>
      <td>Boeing 777-300</td>
      <td>Comfort</td>
      <td>32740.552889</td>
    </tr>
    <tr>
      <th>8</th>
      <td>763</td>
      <td>Boeing 767-300</td>
      <td>Economy</td>
      <td>27594.721829</td>
    </tr>
    <tr>
      <th>9</th>
      <td>773</td>
      <td>Boeing 777-300</td>
      <td>Economy</td>
      <td>19265.225693</td>
    </tr>
    <tr>
      <th>10</th>
      <td>733</td>
      <td>Boeing 737-300</td>
      <td>Economy</td>
      <td>13985.152000</td>
    </tr>
    <tr>
      <th>11</th>
      <td>CR2</td>
      <td>Bombardier CRJ-200</td>
      <td>Economy</td>
      <td>13207.661102</td>
    </tr>
    <tr>
      <th>12</th>
      <td>321</td>
      <td>Airbus A321-200</td>
      <td>Economy</td>
      <td>11534.974764</td>
    </tr>
    <tr>
      <th>13</th>
      <td>SU9</td>
      <td>Sukhoi Superjet-100</td>
      <td>Economy</td>
      <td>11220.183400</td>
    </tr>
    <tr>
      <th>14</th>
      <td>CN1</td>
      <td>Cessna 208 Caravan</td>
      <td>Economy</td>
      <td>6568.552345</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.set_style('dark')
plt.figure(figsize = (10,5))
ax  =  sns.barplot(x = 'model', y = 'avg_amount', hue = 'class', data = df2, palette = 'cool')

for container in ax.containers:
    ax.bar_label(container)

plt.title('Average Price of Flights by Classes')
plt.xticks(rotation = 45)
plt.show()
```


    
![png](output_22_0.png)
    



```python
revenue  =  pd.read_sql_query("""SELECT aircraft_code, model, ticket_count, total_revenue, total_revenue/ticket_count AS avg_revenue_per_ticket FROM
                                 (SELECT a.aircraft_code, JSON_EXTRACT(model, '$.en') AS model,
                                 COUNT(*) AS ticket_count, SUM(tf.amount) AS total_revenue FROM aircrafts_data AS a
                                 JOIN flights AS f
                                 ON a.aircraft_code = f.aircraft_code
                                 JOIN ticket_flights AS tf
                                 ON f.flight_id = tf.flight_id
                                 GROUP BY a.aircraft_code)""", conn)
revenue
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>aircraft_code</th>
      <th>model</th>
      <th>ticket_count</th>
      <th>total_revenue</th>
      <th>avg_revenue_per_ticket</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>319</td>
      <td>Airbus A319-100</td>
      <td>52853</td>
      <td>2706163100</td>
      <td>51201</td>
    </tr>
    <tr>
      <th>1</th>
      <td>321</td>
      <td>Airbus A321-200</td>
      <td>107129</td>
      <td>1638164100</td>
      <td>15291</td>
    </tr>
    <tr>
      <th>2</th>
      <td>733</td>
      <td>Boeing 737-300</td>
      <td>86102</td>
      <td>1426552100</td>
      <td>16568</td>
    </tr>
    <tr>
      <th>3</th>
      <td>763</td>
      <td>Boeing 767-300</td>
      <td>124774</td>
      <td>4371277100</td>
      <td>35033</td>
    </tr>
    <tr>
      <th>4</th>
      <td>773</td>
      <td>Boeing 777-300</td>
      <td>144376</td>
      <td>3431205500</td>
      <td>23765</td>
    </tr>
    <tr>
      <th>5</th>
      <td>CN1</td>
      <td>Cessna 208 Caravan</td>
      <td>14672</td>
      <td>96373800</td>
      <td>6568</td>
    </tr>
    <tr>
      <th>6</th>
      <td>CR2</td>
      <td>Bombardier CRJ-200</td>
      <td>150122</td>
      <td>1982760500</td>
      <td>13207</td>
    </tr>
    <tr>
      <th>7</th>
      <td>SU9</td>
      <td>Sukhoi Superjet-100</td>
      <td>365698</td>
      <td>5114484700</td>
      <td>13985</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Define the SQL query to create the view

# Drop the existing table 'bh' if it exists
drop_table_query = "DROP VIEW IF EXISTS flight_booked_seats;"
cursor.execute(drop_table_query)

# Create the view 'bbh'
create_view_query = """
CREATE VIEW flight_booked_seats AS
SELECT aircraft_code, flights.flight_id, COUNT(*) as seats_count
FROM boarding_passes
INNER JOIN flights 
ON boarding_passes.flight_id=flights.flight_id
GROUP BY aircraft_code, flights.flight_id;
"""
cursor.execute(create_view_query)

# Commit the changes to the database
conn.commit()

# Now you can read the view data using a SELECT query
f_b_s = pd.read_sql_query("SELECT * FROM flight_booked_seats", conn)

f_b_s
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>aircraft_code</th>
      <th>flight_id</th>
      <th>seats_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>319</td>
      <td>1162</td>
      <td>51</td>
    </tr>
    <tr>
      <th>1</th>
      <td>319</td>
      <td>1166</td>
      <td>54</td>
    </tr>
    <tr>
      <th>2</th>
      <td>319</td>
      <td>1167</td>
      <td>57</td>
    </tr>
    <tr>
      <th>3</th>
      <td>319</td>
      <td>1168</td>
      <td>60</td>
    </tr>
    <tr>
      <th>4</th>
      <td>319</td>
      <td>1170</td>
      <td>58</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>11513</th>
      <td>SU9</td>
      <td>32925</td>
      <td>12</td>
    </tr>
    <tr>
      <th>11514</th>
      <td>SU9</td>
      <td>32928</td>
      <td>25</td>
    </tr>
    <tr>
      <th>11515</th>
      <td>SU9</td>
      <td>32931</td>
      <td>12</td>
    </tr>
    <tr>
      <th>11516</th>
      <td>SU9</td>
      <td>32933</td>
      <td>16</td>
    </tr>
    <tr>
      <th>11517</th>
      <td>SU9</td>
      <td>32937</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
<p>11518 rows × 3 columns</p>
</div>




```python
# Define the SQL query to create the view

# Drop the existing table 'num_seats' if it exists
drop_table_query = "DROP VIEW IF EXISTS num_seats;"
cursor.execute(drop_table_query)

# Create the view 'num_seats'
create_view_query = """
CREATE VIEW num_seats AS
SELECT s.aircraft_code, JSON_EXTRACT(model, '$.en') AS model, COUNT(*) AS num_seats 
                             FROM seats AS s
                             JOIN aircrafts_data AS a
                             ON s.aircraft_code = a.aircraft_code
                             GROUP BY s.aircraft_code
                             
                             ORDER BY num_seats DESC;
"""
cursor.execute(create_view_query)

# Commit the changes to the database
conn.commit()

# Now you can read the view data using a SELECT query
num_seats = pd.read_sql_query("SELECT * FROM num_seats", conn)

num_seats
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>aircraft_code</th>
      <th>model</th>
      <th>num_seats</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>773</td>
      <td>Boeing 777-300</td>
      <td>402</td>
    </tr>
    <tr>
      <th>1</th>
      <td>763</td>
      <td>Boeing 767-300</td>
      <td>222</td>
    </tr>
    <tr>
      <th>2</th>
      <td>321</td>
      <td>Airbus A321-200</td>
      <td>170</td>
    </tr>
    <tr>
      <th>3</th>
      <td>320</td>
      <td>Airbus A320-200</td>
      <td>140</td>
    </tr>
    <tr>
      <th>4</th>
      <td>733</td>
      <td>Boeing 737-300</td>
      <td>130</td>
    </tr>
    <tr>
      <th>5</th>
      <td>319</td>
      <td>Airbus A319-100</td>
      <td>116</td>
    </tr>
    <tr>
      <th>6</th>
      <td>SU9</td>
      <td>Sukhoi Superjet-100</td>
      <td>97</td>
    </tr>
    <tr>
      <th>7</th>
      <td>CR2</td>
      <td>Bombardier CRJ-200</td>
      <td>50</td>
    </tr>
    <tr>
      <th>8</th>
      <td>CN1</td>
      <td>Cessna 208 Caravan</td>
      <td>12</td>
    </tr>
  </tbody>
</table>
</div>




```python
occupancy_rate  =  pd.read_sql_query("""SELECT a.aircraft_code, model, b.num_seats, ROUND(AVG(a.seats_count)) AS booked_seats, AVG(a.seats_count)/b.num_seats AS occupancy_rate
                                        FROM flight_booked_seats AS a
                                        JOIN num_seats AS b
                                        ON a.aircraft_code = b.aircraft_code
                                        GROUP BY a.aircraft_code
                                        ORDER BY occupancy_rate DESC""", conn)
occupancy_rate
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>aircraft_code</th>
      <th>model</th>
      <th>num_seats</th>
      <th>booked_seats</th>
      <th>occupancy_rate</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>773</td>
      <td>Boeing 777-300</td>
      <td>402</td>
      <td>265.0</td>
      <td>0.659019</td>
    </tr>
    <tr>
      <th>1</th>
      <td>733</td>
      <td>Boeing 737-300</td>
      <td>130</td>
      <td>80.0</td>
      <td>0.617350</td>
    </tr>
    <tr>
      <th>2</th>
      <td>SU9</td>
      <td>Sukhoi Superjet-100</td>
      <td>97</td>
      <td>57.0</td>
      <td>0.585692</td>
    </tr>
    <tr>
      <th>3</th>
      <td>321</td>
      <td>Airbus A321-200</td>
      <td>170</td>
      <td>89.0</td>
      <td>0.522407</td>
    </tr>
    <tr>
      <th>4</th>
      <td>763</td>
      <td>Boeing 767-300</td>
      <td>222</td>
      <td>114.0</td>
      <td>0.513231</td>
    </tr>
    <tr>
      <th>5</th>
      <td>CN1</td>
      <td>Cessna 208 Caravan</td>
      <td>12</td>
      <td>6.0</td>
      <td>0.500369</td>
    </tr>
    <tr>
      <th>6</th>
      <td>319</td>
      <td>Airbus A319-100</td>
      <td>116</td>
      <td>54.0</td>
      <td>0.461924</td>
    </tr>
    <tr>
      <th>7</th>
      <td>CR2</td>
      <td>Bombardier CRJ-200</td>
      <td>50</td>
      <td>21.0</td>
      <td>0.429657</td>
    </tr>
  </tbody>
</table>
</div>




```python
occupancy_rate['Inc occupancy_rate']  =  occupancy_rate['occupancy_rate']  +  occupancy_rate['occupancy_rate'] * 0.1

occupancy_rate
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>aircraft_code</th>
      <th>model</th>
      <th>num_seats</th>
      <th>booked_seats</th>
      <th>occupancy_rate</th>
      <th>Inc occupancy_rate</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>773</td>
      <td>Boeing 777-300</td>
      <td>402</td>
      <td>265.0</td>
      <td>0.659019</td>
      <td>0.724921</td>
    </tr>
    <tr>
      <th>1</th>
      <td>733</td>
      <td>Boeing 737-300</td>
      <td>130</td>
      <td>80.0</td>
      <td>0.617350</td>
      <td>0.679085</td>
    </tr>
    <tr>
      <th>2</th>
      <td>SU9</td>
      <td>Sukhoi Superjet-100</td>
      <td>97</td>
      <td>57.0</td>
      <td>0.585692</td>
      <td>0.644261</td>
    </tr>
    <tr>
      <th>3</th>
      <td>321</td>
      <td>Airbus A321-200</td>
      <td>170</td>
      <td>89.0</td>
      <td>0.522407</td>
      <td>0.574648</td>
    </tr>
    <tr>
      <th>4</th>
      <td>763</td>
      <td>Boeing 767-300</td>
      <td>222</td>
      <td>114.0</td>
      <td>0.513231</td>
      <td>0.564554</td>
    </tr>
    <tr>
      <th>5</th>
      <td>CN1</td>
      <td>Cessna 208 Caravan</td>
      <td>12</td>
      <td>6.0</td>
      <td>0.500369</td>
      <td>0.550406</td>
    </tr>
    <tr>
      <th>6</th>
      <td>319</td>
      <td>Airbus A319-100</td>
      <td>116</td>
      <td>54.0</td>
      <td>0.461924</td>
      <td>0.508116</td>
    </tr>
    <tr>
      <th>7</th>
      <td>CR2</td>
      <td>Bombardier CRJ-200</td>
      <td>50</td>
      <td>21.0</td>
      <td>0.429657</td>
      <td>0.472623</td>
    </tr>
  </tbody>
</table>
</div>




```python
total_revenue = pd.read_sql_query("""SELECT aircraft_code, SUM(amount) as total_revenue  FROM ticket_flights
                        JOIN flights 
                        ON ticket_flights.flight_id=flights.flight_id 
                        GROUP BY aircraft_code""", conn)

total_revenue
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>aircraft_code</th>
      <th>total_revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>319</td>
      <td>2706163100</td>
    </tr>
    <tr>
      <th>1</th>
      <td>321</td>
      <td>1638164100</td>
    </tr>
    <tr>
      <th>2</th>
      <td>733</td>
      <td>1426552100</td>
    </tr>
    <tr>
      <th>3</th>
      <td>763</td>
      <td>4371277100</td>
    </tr>
    <tr>
      <th>4</th>
      <td>773</td>
      <td>3431205500</td>
    </tr>
    <tr>
      <th>5</th>
      <td>CN1</td>
      <td>96373800</td>
    </tr>
    <tr>
      <th>6</th>
      <td>CR2</td>
      <td>1982760500</td>
    </tr>
    <tr>
      <th>7</th>
      <td>SU9</td>
      <td>5114484700</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Set the float formatting options
pd.options.display.float_format = '{:.1f}'.format


occupancy_rate['Inc Total Annual Turnover']  =  (total_revenue['total_revenue']/occupancy_rate['occupancy_rate']) * occupancy_rate['Inc occupancy_rate']

occupancy_rate
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>aircraft_code</th>
      <th>model</th>
      <th>num_seats</th>
      <th>booked_seats</th>
      <th>occupancy_rate</th>
      <th>Inc occupancy_rate</th>
      <th>Inc Total Annual Turnover</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>773</td>
      <td>Boeing 777-300</td>
      <td>402</td>
      <td>265.0</td>
      <td>0.7</td>
      <td>0.7</td>
      <td>2976779410.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>733</td>
      <td>Boeing 737-300</td>
      <td>130</td>
      <td>80.0</td>
      <td>0.6</td>
      <td>0.7</td>
      <td>1801980510.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>SU9</td>
      <td>Sukhoi Superjet-100</td>
      <td>97</td>
      <td>57.0</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>1569207310.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>321</td>
      <td>Airbus A321-200</td>
      <td>170</td>
      <td>89.0</td>
      <td>0.5</td>
      <td>0.6</td>
      <td>4808404810.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>763</td>
      <td>Boeing 767-300</td>
      <td>222</td>
      <td>114.0</td>
      <td>0.5</td>
      <td>0.6</td>
      <td>3774326050.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>CN1</td>
      <td>Cessna 208 Caravan</td>
      <td>12</td>
      <td>6.0</td>
      <td>0.5</td>
      <td>0.6</td>
      <td>106011180.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>319</td>
      <td>Airbus A319-100</td>
      <td>116</td>
      <td>54.0</td>
      <td>0.5</td>
      <td>0.5</td>
      <td>2181036550.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>CR2</td>
      <td>Bombardier CRJ-200</td>
      <td>50</td>
      <td>21.0</td>
      <td>0.4</td>
      <td>0.5</td>
      <td>5625933170.0</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
